import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'University Attendance',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key? key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class Student {
  final String name;
  bool isPresent;

  Student({required this.name, this.isPresent = false});

  void toggleAttendance() {
    isPresent = !isPresent;
  }
}

class _MyHomePageState extends State<MyHomePage> {
  final List<Student> students = [
    Student(name: 'Ramanathan Krishnan'),
    Student(name: 'Alex'),
    Student(name: 'Sherin'),
    Student(name: 'Mahesh Bhupathi'),
    Student(name: 'Deva'),
    Student(name: 'Ramesh Krishnan'),
    Student(name: 'Vijay Amritraj'),
    Student(name: 'Sumit'),
    Student(name: 'Leander Paes'),
    Student(name: 'Rohan')

    // Add more students here
  ];

  void toggleStudentAttendance(Student student) {
    setState(() {
      student.toggleAttendance();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('University Attendance'),
      ),
      body: ListView.builder(
        itemCount: students.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(students[index].name),
            trailing: students[index].isPresent
                ? Icon(Icons.check, color: Colors.green)
                : Icon(Icons.close, color: Colors.red),
            onTap: () {
              toggleStudentAttendance(students[index]);
            },
          );
        },
      ),
    );
  }
}
